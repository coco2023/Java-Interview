public interface RPSPlayer
{
    String move();
    int getWins();
    void won();
}