public class CompilationTest
{
    
    public static void test()
    {
        double y = 42;
        int x = 22;
    if (x < 10)
    {
        System.out.println(x);
    }
    else
        System.out.println(y);
        System.out.println("hello");

    }
    
    public static void main(String[] args)
    {
        test();
    }
}
