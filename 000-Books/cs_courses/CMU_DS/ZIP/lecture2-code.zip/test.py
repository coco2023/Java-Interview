def test():
    x = 22
    if x < 10:
        print(x)
    else:
        print(y)

test()

